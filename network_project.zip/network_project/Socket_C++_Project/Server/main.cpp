#include <queue>
#include "../Packet.h"

void TestJob();

unsigned int connectCount = 0;
unsigned int disconnectCount = 0;

class Server : public HNET::Acceptor
{
public:
    ~Server()
    {

    }

    void OnConnected(NetId netId) override
    {
        InterlockedIncrement(&connectCount);
    }

    void OnDisconnected(NetId netId, const wchar_t* pReason) override
    {
        InterlockedIncrement(&disconnectCount);
    }

    void OnRegMessage() override
    {
        RegMessage(&Server::Message_Echo);
    }

    void Message_Echo(NetId netId, const Echo& Packet)
    {
        if (false)
        {
            // send packet.
            HNET::NewPacketT<Echo> echo;
            Send(netId, echo);
            //SendAll(echo);
            return;
        }

        AddReference(netId);
        HNET::JOB::Post(netId, [=]()
        {
            HNET::NewPacketT<Echo> echo;
            Send(netId, echo);

            ReleaseReference(netId);
        });
    }

public:
    // "single" or "multi" thread mode.
    bool IsSingleThread() override
    {
        //return true;
        return false;
    }
};

void Display()
{
    static ULONGLONG  tick = 0;
    static SYSTEMTIME time;

    if (0 == tick)
    {
        GetLocalTime(&time);
        HAPI::Print(2, 1, L"start   time => %2d: %2d: %2d", time.wHour, time.wMinute, time.wSecond);
    }

    if (GetTickCount64() - tick > 1000)
    {
        tick = GetTickCount64();

        GetLocalTime(&time);
        HAPI::Print(2, 2, L"current time => %2d: %2d: %2d", time.wHour, time.wMinute, time.wSecond);

        HAPI::PrintG(2, 4, L"- server connect:    %d", connectCount);
        HAPI::PrintR(2, 6, L"- server disconnect: %d", disconnectCount);
    }
}

void main()
{
    TestJob();
    //for (int count = 0; count < 100; ++count)
    //{
    //    HNET::JOB::Post(count, []()
    //    {
    //        int a = GetCurrentThreadId();
    //        //printf("\n %d", a);
    //        
    //        HNET::JOB::Post([=]()
    //        {
    //            printf("\n 1. %d, %d", a, GetCurrentThreadId());
    //        });
    //    });
    //}

    //for (int count = 0; count < 100; ++count)
    //{
    //    HNET::JOB::Post([]()
    //    {
    //        int a = GetCurrentThreadId();
    //        HNET::JOB::Post([=]()
    //        {
    //            printf("\n 2. %d, %d", a, GetCurrentThreadId());
    //        });
    //    });
    //}

    Sleep(1000000);

    Server server;
    if (false == server.Listen())
        return;

    while (true)
    {
        Display();

        if (server.IsSingleThread())
        {
            server.Update();
            Sleep(1);
        }
        else
        {
            Sleep(300);
        }
    }
}

void TestJob()
{
    DWORD time = timeGetTime();

    int loop = 10000000;

    for (int i = 0; i <= loop; ++i)
    {
        HNET::JOB::Post([=]()
        {
            //printf("AAA> ID: %d, count: %d, time: %d\n", HNET::JOB::CurrentJobID(), i + 1, timeGetTime() - time);

            //HNET::JOB::Post([=]()
            //{
            //    printf("CCC> ID: %d, count: %d, time: %d\n", HNET::JOB::CurrentJobID(), i + 1, timeGetTime() - time);
            //}, 
            //3000 + (200 * i));

            if (loop == i)
            {
                int s = timeGetTime() - time;

                HNET::JOB::Post([=]()
                    {
                        printf("\ncount: %d, time: %d\n\n", i, s);
                    }, 100);
            }
        });    //}, 10 + (20 * i));
    }
}