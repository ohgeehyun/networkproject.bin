
#include "../Packet.h"

unsigned int connectCount = 0;
unsigned int reconnectCount = 0;
unsigned int disconnectCount = 0;

class Client : public HNET::Connector
{
	void OnConnected() override
	{
        InterlockedIncrement(&connectCount);

        HNET::NewPacketT<HelloPacket> Out;
        Out->hello = 77;
        Send(Out);
        
        //Out.Reuse();
        //Send(Out);
	}

    void OnReconnected() override
    {
        InterlockedIncrement(&reconnectCount);

        HNET::NewPacketT<HelloPacket> Out;
        Out->hello = 88;
        Send(Out);
    }

	void OnDisconnected(IN const wchar_t* reason) override
	{
        InterlockedIncrement(&disconnectCount);
	}

	void OnRegMessage() override
	{
		RegMessage(&Client::Message_World);
	}

	void Message_World(const WorldPacket& packet)
	{
		HNET::NewPacketT<HelloPacket> Out;
		Out->hello = packet.world;
		//Send(Out);
	}

public:
    bool SingleThread()
    {
        return false;
    }
};

void main()
{
    Client client;
    client.Connect();
    //client.Connect(L"jjindda2001.iptime.org");
    //client.Connect(L"fe80::71a7:3eea:1b03:1689");
    
    while (true)
    {
        //client.Connect();
        HNET::NewPacketT<Echo> Out;
        client.Send(Out);
        //client.Disconnect();
        //client.Send(echo);

        if (client.SingleThread())
        {
            client.Update();
        }
        
        Sleep(1);

        HAPI::Print(2, 1, L"============ CLIENT ============");
        
        HAPI::PrintG(1, 3, L"client connect.(%d)",    connectCount);
        HAPI::PrintY(1, 4, L"client reconnect.(%d)",  reconnectCount);
        HAPI::PrintR(1, 5, L"client disconnect.(%d)", disconnectCount);
    }
}
