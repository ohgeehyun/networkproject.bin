#pragma once

#include "Common.h"

#define _W(X) L##X
#define __W(X) _W(X)

//��=============================================================================================��
//   LOG.
//��=============================================================================================��
class SystemLogger : public HNET::LIB::Logger {};
SystemLogger* Log();

#define LOG_INFO(FORMAT, ...)        Log()->Write(LOG_TYPE_INFO,       FORMAT, __VA_ARGS__)
#define LOG_ERROR(FORMAT, ...)       Log()->Write(LOG_TYPE_ERROR,      FORMAT, __VA_ARGS__)
#define LOG_CRITICAL(FORMAT, ...)    Log()->Write(LOG_TYPE_CRITICAL,   FORMAT, __VA_ARGS__)
#define LOG_WARNING(FORMAT, ...)     Log()->Write(LOG_TYPE_WARNING,    FORMAT, __VA_ARGS__)
#define LOG_FAIL(FORMAT, ...)        Log()->Write(LOG_TYPE_FAIL,       FORMAT, __VA_ARGS__)
#define LOG_LAST_ERROR(FORMAT, ...)  Log()->Write(LOG_TYPE_LAST_ERROR, FORMAT, __VA_ARGS__)

#ifdef _DEBUG
    #define LOG_INFO_DEBUG(FORMAT, ...)       LOG_INFO(FORMAT,       __VA_ARGS__)
    #define LOG_ERROR_DEBUG(FORMAT, ...)      LOG_ERROR(FORMAT,      __VA_ARGS__)
    #define LOG_CRITICAL_DEBUG(FORMAT, ...)   LOG_CRITICAL(FORMAT,   __VA_ARGS__)
    #define LOG_WARNING_DEBUG(FORMAT, ...)    LOG_WARNING(FORMAT,    __VA_ARGS__)
    #define LOG_FAIL_DEBUG(FORMAT, ...)       LOG_FAIL(FORMAT,       __VA_ARGS__)
    #define LOG_LAST_ERROR_DEBUG(FORMAT, ...) LOG_LAST_ERROR(FORMAT, __VA_ARGS__)
#else
    #define LOG_INFO_DEBUG(FORMAT, ...)
    #define LOG_ERROR_DEBUG(FORMAT, ...)
    #define LOG_CRITICAL_DEBUG(FORMAT, ...)
    #define LOG_WARNING_DEBUG(FORMAT, ...)
    #define LOG_FAIL_DEBUG(FORMAT, ...)
    #define LOG_LAST_ERROR_DEBUG(FORMAT, ...)
#endif

namespace HNET
{
    namespace SINGLETON
    {
        void SystemLogReference();
        void SystemLogRelease();
    }
}

namespace HNET
{
    namespace OPTION
    {
        //��=============================================================================================��
        //   HNetwork �ý����� �α׸� ��� ����.
        //��=============================================================================================��
        void SetSystemLog(bool b);

        
        //��=============================================================================================��
        //   �α� ���� ���� ����.
        //��=============================================================================================��
        bool SetLogFilePath(const wchar_t* path);
    }
}

class JobHander : public Job {};
JobHander* Job();

namespace HNET
{
    namespace JOB
    {
        void Update();

        void Post(unsigned int id, std::function<void()> f /* = [](){ } */, DWORD delay = 0);
        void Post(std::function<void()> f /* = [](){ } */, DWORD delay = 0);
    }
}

namespace HNET
{
    namespace API
    {
        void Sleep(int milliseconds);
        
        //��=============================================================================================��
        //   �̴� ����.
        //��=============================================================================================��
        void MiniDump();


        //��=============================================================================================��
        //   �ܼ� ȭ�鿡 ���ڿ� ���.
        //��=============================================================================================��
        void Print(SHORT x, SHORT y, const wchar_t* format, ...);
        void PrintR(SHORT x, SHORT y, const wchar_t* format, ...);
        void PrintG(SHORT x, SHORT y, const wchar_t* format, ...);
        void PrintB(SHORT x, SHORT y, const wchar_t* format, ...);
        void PrintY(SHORT x, SHORT y, const wchar_t* format, ...);


        //��=============================================================================================��
        //   ������ ������ ���ڿ��� ��ȯ.(�α׵� ���)
        //��=============================================================================================��
	    bool LastError(const wchar_t* format = NULL, ...);

        #define LAST_ERROR_DETAIL() HNET::API::LastError(L"function=\"%s\", line=\"%d\"", __W(__FUNCTION__), __LINE__)
        
		
		//��=============================================================================================��
		//   ���� ����. (�����ϰų� �̹� ���� �Ѵٸ� true ����.)
		//��=============================================================================================��
		bool CreateFolder(const wchar_t* path);
        

		//��=============================================================================================��
		//   ����� ��忡�� ���ڿ� ����. ("��" ���� ���ڰ� �߰���)
		//��=============================================================================================��
		void OutputDebugText(const wchar_t* string);


        //��=============================================================================================��
        //   �޽��� �ڽ�.
        //��=============================================================================================��
        void MsgBox(const wchar_t* title, const wchar_t* format, ...);

        #define MSG_BOX(TITLE, FORMAT, ...) HNET::API::MsgBox(TITLE, FORMAT, __VA_ARGS__)
        #define MSG_BOX_DETAIL(TITLE)       HNET::API::MsgBox(TITLE, L"filename=\"%s\", line=\"%d\", function=\"%s\"", __W(__FILE__), __LINE__, __W(__FUNCTION__))


        //��=============================================================================================��
        //   ȣ��Ʈ ������.
        //��=============================================================================================��
        const wchar_t* HostToIp(const wchar_t* host);

        
        //��=============================================================================================��
        //   ���� ������.
        //��=============================================================================================��
        const wchar_t* LocalIp();


	    //��=============================================================================================��
        //   �޸𸮸� �극��ũ ����Ʈ ����.
        //��=============================================================================================��
        void BreakMemoryLeak(int number);


        //��=============================================================================================��
        //   ���� ���丮.
        //��=============================================================================================��
        const wchar_t* Directory();

        
        //��=============================================================================================��
        //   ���� ����̺�.
        //��=============================================================================================��
        wchar_t DiskDrive();

        
        //��=============================================================================================��
        //   �α� ���� ���.
        //��=============================================================================================��
        const wchar_t* LogFilePath();
        

        //��=============================================================================================��
        //   ���� ���� �̸�.
        //��=============================================================================================��
        const wchar_t* ExeFileName();


        //��=============================================================================================��
        //   �޸� ��뷮.
        //��=============================================================================================��
        SIZE_T MemoryUsage();      // ���� ��뷮.
        SIZE_T& MemoryUsageMax();  // �ִ� ��뷮.


	    //��=============================================================================================��
        //   �ϵ��� �� ����.
        //��=============================================================================================��
	    int HddFreeSpace(wchar_t drive = DiskDrive());


	    //��=============================================================================================��
        //   ���μ��� ����.
        //��=============================================================================================��
	    DWORD ProcessorCount();

        
        //��=============================================================================================��
        //   ������ ĸ��.
        //��=============================================================================================��
        const wchar_t* WindowCaption();


        //��=============================================================================================��
        //   ������ ĸ������ HWND ���.
        //��=============================================================================================��
        HWND WindowNameToHwnd(const wchar_t* windowName = WindowCaption());

        
        //��=============================================================================================��
        //   ���μ��� ���̵�� HWND ���.
        //��=============================================================================================��
        HWND ProcessIdToHwnd(ULONG processId = GetCurrentProcessId());

        
        //��=============================================================================================��
        //   �ð�.
        //��=============================================================================================��
        time_t     ConvertToTime(const SYSTEMTIME& time);                                    // SYSTEMTIME -> time_t.
        FILETIME   ConvertToFileTime(const SYSTEMTIME& time);                                // SYSTEMTIME -> FILETIME.
        SYSTEMTIME ConvertToSystemTime(FILETIME time);                                       // FILETIME   -> SYSTEMTIME.
        SYSTEMTIME ConvertToSystemTime(const time_t time);                                   // time_t     -> SYSTEMTIME.
        bool       BetweenTime(const SYSTEMTIME& startTime, const SYSTEMTIME& endTime);      // '����ð�'�� '���۽ð�'�� '���ð�' �ȿ� �ִ��� Ȯ��.  
        bool       TimeOver(const SYSTEMTIME& time);                                         // �ð��� ��������.
        WORD       DaysPassed(const SYSTEMTIME& time);                                       // ������ ��������.
        WORD       HoursPassed(const SYSTEMTIME& time);                                      // ��ð��� ��������.
        WORD       MinutesPassed(const SYSTEMTIME& time);                                    // ����� ��������.


        //��=============================================================================================��
        //   ���ڿ� ��ȯ.
        //��=============================================================================================��
        const wchar_t* CharToWChar(const char* string);
        const char*    WCharToChar(const wchar_t* string);
        const char*    CharToUtf8(const char* string);
        const char*    WCharToUtf8(const wchar_t* string);

        //��=============================================================================================��
        //   ���ڿ� ó��.
        //��=============================================================================================��
		size_t StringLenth(const char* string);
		size_t StringLenth(const wchar_t* string);
        bool StringCompare(const char* string1, const char* string2);
        bool StringCompare(const wchar_t* string1, const wchar_t* string2);
        const char* StringFormat(const char* format, ...);
        const wchar_t* StringFormat(const wchar_t* format, ...);
        template<int N> bool StringCopy(OUT char (&dest)[N], const char* src);
        template<int N> bool StringCopy(OUT wchar_t (&dest)[N], const wchar_t* src);
        template<int N> bool StringCat(OUT char (&dest)[N], const char* src);
        template<int N> bool StringCat(OUT wchar_t (&dest)[N], const wchar_t* src);
        template<int N> bool StringPrintf(OUT char (&dest)[N], const char* format, ...);
        template<int N> bool StringPrintf(OUT wchar_t (&dest)[N], const wchar_t* format, ...);
        template<int N> bool StringVPrintf(OUT char (&dest)[N], const char* format, va_list& Args);
        template<int N> bool StringVPrintf(OUT wchar_t (&dest)[N], const wchar_t* format, va_list& Args);
    }
}

void WSAStart();
void WSAEnd();

HNET::LIB::Logger* SystemLog();
#define LOG_INFO_SYSTEM(FORMAT, ...)        SystemLog() ? SystemLog()->Write(LOG_TYPE_INFO,       FORMAT, __VA_ARGS__) : 0
#define LOG_ERROR_SYSTEM(FORMAT, ...)       SystemLog() ? SystemLog()->Write(LOG_TYPE_ERROR,      FORMAT, __VA_ARGS__) : 0
#define LOG_CRITICAL_SYSTEM(FORMAT, ...)    SystemLog() ? SystemLog()->Write(LOG_TYPE_CRITICAL,   FORMAT, __VA_ARGS__) : 0
#define LOG_WARNING_SYSTEM(FORMAT, ...)     SystemLog() ? SystemLog()->Write(LOG_TYPE_WARNING,    FORMAT, __VA_ARGS__) : 0
#define LOG_FAIL_SYSTEM(FORMAT, ...)        SystemLog() ? SystemLog()->Write(LOG_TYPE_FAIL,       FORMAT, __VA_ARGS__) : 0
#define LOG_LAST_ERROR_SYSTEM(FORMAT, ...)  SystemLog() ? SystemLog()->Write(LOG_TYPE_LAST_ERROR, FORMAT, __VA_ARGS__) : 0
#define LOG_LAST_ERROR_DETAIL_SYSTEM()      SystemLog() ? HNET::API::LastError(L"function( \"%s\" ), line( \"%d\" )", __W(__FUNCTION__), __LINE__) : 0

template<int N>
bool HNET::API::StringCopy(OUT char (&dest)[N], const char* src)
{
    dest[0] = '\0';

    if (dest == src || NULL == src)
        return false;

    return (0 == strncpy_s(dest, N, src, _TRUNCATE));
}

template<int N> 
bool HNET::API::StringCopy(OUT wchar_t (&dest)[N], const wchar_t* src)
{
    dest[0] = '\0';

    if (dest == src || NULL == src)
        return false;

    return (0 == wcsncpy_s(dest, N, src, _TRUNCATE));
}

template<int N>
bool HNET::API::StringCat(OUT char (&dest)[N], const char* src)
{
    dest[N - 1] = '\0';

    if (dest == src || NULL == src)
        return false;

    return (0 == strncat_s(dest, N, src, _TRUNCATE));
}

template<int N>
bool HNET::API::StringCat(OUT wchar_t (&dest)[N], const wchar_t* src)
{
    dest[N - 1] = '\0';

    if (dest == src || NULL == src)
        return false;

    return (0 == wcsncat_s(dest, N, src, _TRUNCATE));
}

template<int N>
bool HNET::API::StringPrintf(OUT char (&dest)[N], const char* format, ...)
{
    dest[0] = '\0';

    if (dest == format || NULL == format)
        return false;

    va_list Args;
    va_start(Args, format);
        bool result = (0 < _vsnprintf_s(dest, N, _TRUNCATE, format, Args));
    va_end(Args);

    return result;
}

template<int N>
bool HNET::API::StringPrintf(OUT wchar_t (&dest)[N], const wchar_t* format, ...)
{
    dest[0] = '\0';

    if (dest == format || NULL == format)
        return false;

    va_list Args;
    va_start(Args, format);
       bool result = (0 < _vsnwprintf_s(dest, N, _TRUNCATE, format, Args));
    va_end(Args);

    return result;
}

template<int N>
bool HNET::API::StringVPrintf(OUT char (&dest)[N], const char* format, va_list& Args)
{
    dest[0] = '\0';

    if (dest == format || NULL == format)
        return false;

    return (0 < _vsnprintf_s(dest, N, _TRUNCATE, format, Args));
}

template<int N>
bool HNET::API::StringVPrintf(OUT wchar_t (&dest)[N], const wchar_t* format, va_list& Args)
{
    dest[0] = '\0';

    if (dest == format || NULL == format)
        return false;

    return (0 < _vsnwprintf_s(dest, N, _TRUNCATE, format, Args));
}