#pragma once

#include <windows.h>

namespace HNET
{
    namespace LIB
    {
        class Memory
        {
        public:
            void* operator new(size_t size);
            void operator delete(void* p);

            void* operator new[](size_t size);
            void operator delete[](void* p);
        };
    }

    namespace API
    {
        void* Alloc(size_t size);
        void Dealloc(void* p);

        template<typename T> void Constructor(T* p) { new(p) T; } // ������ ȣ�� �Լ�.
        template<typename T> void Destructor(T* p)  { p->~T(); }  // �Ҹ��� ȣ�� �Լ�.
    }

    namespace SINGLETON
    {
        void MemoryReference();
        void MemoryRelease();
    }
}