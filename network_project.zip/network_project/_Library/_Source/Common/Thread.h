#pragma once

#include <windows.h>

namespace HNET
{
    namespace LIB
    {
        class Thread
        {
            virtual void OnWorker() = 0;

        protected:
	        Thread(const wchar_t* name = L"thread");

        public:
            virtual ~Thread();

	        bool Run();
		    void Wait(DWORD waitMillisecond = INFINITE); // ȣ����ġ���� signal �߻����� ���.
            void Pulse();                                // signal �߻�.

        private:
	        static unsigned WINAPI _Worker(void* param);

        private:
	        HANDLE  _thread;        // �ڵ�.
            HANDLE  _event;         // �̺�Ʈ.
            wchar_t _name[1024];    // �̸�.
        };
    }
}